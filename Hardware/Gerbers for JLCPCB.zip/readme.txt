JLCPCB order

Base Material				FR-4
Layers						8
Dimensions					38.2*49.2
PCB Qty						5
Product Type				Industrial/Consumer electronics

Different Design			1
Delivery Format				Single PCB
Panel Format				2*2
PCB Thickness				1.0
PCB Color					Green
Silkscreen					White
Material Type				FR-4 TG155
Surface Finish				ENIG
Gold Thickness				2U"

Outer Copper Weight			1 oz
Inner Copper Weight			0.5 oz
Specify Layer Sequence		No
Specify Stackup				No
Via Covering				Epoxy Filled & Capped
Min via hole size/diameter  0.3mm
Board Outline Tolerance		0.2mm (Regular)
Confirm Production File		No
Mark on PCB 				Remove Mark
Electrical Test 			Flying Probe Fully Test
Gold Fingers				No
Castellated Holes			No
Press-Fit Hole 				No
Edge Plating				No
Blind Slots					No

PCB Remark: Layers MN82.GP1, MN82.GP2, MN82.GP3 and MN82.GP4 are planes and drawn inverted.